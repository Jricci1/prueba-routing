class UsersController < ApplicationController

	require 'faraday'

	def foo
		@response = []
		dir = params[:contenido][:text]
		xlsx = Roo::Spreadsheet.open(dir)
		xlsx.each do |address|
			address1 = address[0].gsub " ", "_"
			address1.gsub! "ñ", "@"
			address1.gsub! "Ñ", "@"
			address1.gsub! "°", ""
			address1.gsub! "\u{aa}", ""
			address1.gsub! "#", ""
			uri = 'http://localhost:8080/normalizador/%s' % (address1)
			res = Faraday.get uri
			@response << [address[0], res.body.gsub('@', 'Ñ')]
		end
	end

end
